# praktek_script.py

from termcolor import colored

def main():
    print(colored("Selamat anda berhasil mem-praktek-kan Git Clone", 'red', attrs=['bold']))

if __name__ == "__main__":
    main()
